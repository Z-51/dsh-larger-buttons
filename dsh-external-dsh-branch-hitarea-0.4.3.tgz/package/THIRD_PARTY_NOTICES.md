# 第三方组件说明

`lib/schema.js` 内含以下组件的构建代码，保留其 MIT 许可证：

- `@deepseek-ai/schemastery` 3.18.4：见 `vendor/schemastery.LICENSE`。
- `@deepseek-ai/cosmokit` 1.8.5：见 `vendor/cosmokit.LICENSE`。

客户端在 DeepSeek Harness 宿主环境中运行，并复用宿主提供的 React、ReactDOM、Cordis 和 UI 插槽。分发包未附带宿主安装程序或这些宿主模块。

本分发包不包含从宿主提取的测试 CSS、测试夹具、个人配置或账号数据。
